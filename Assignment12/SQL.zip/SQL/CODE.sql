﻿DROP TRIGGER IF EXISTS AccountRecordInsert on AccountRecords;

CREATE OR REPLACE FUNCTION recordinsertfnc()
RETURNS trigger 
AS
$BODY$
BEGIN
	INSERT INTO RecordInserts( RID, AID, username ) 
	VALUES (NEW.RID, NEW.AID, user );

	RETURN NEW;
END;
$BODY$
LANGUAGE PLPGSQL;

CREATE TRIGGER AccountRecordInsert
AFTER INSERT ON AccountRecords
FOR EACH ROW EXECUTE PROCEDURE recordInsertFnc();

CREATE OR REPLACE VIEW Customers
AS
SELECT P.PID, P.pname, P.pgender, p.pheight
FROM People P
WHERE P.PID in (SELECT PID FROM Accounts);
			 
CREATE OR REPLACE VIEW Records
AS
SELECT A.AID, R.rBalance, R.rAmount
FROM Accounts A JOIN AccountRecords R ON R.AID = A.AID;
		
CREATE OR REPLACE FUNCTION NewCustomer(
	IN m_PID int,
	IN m_pname VARCHAR(50),
	IN m_pgender CHAR(1),
	IN m_pheight FLOAT
) 
RETURNS VOID 
AS 
$BODY$
BEGIN
	INSERT INTO People ( PID, pname, pgender, pheight ) 
	VALUES ( m_PID, m_pname, m_pgender, m_pheight );
END;
$BODY$ 
LANGUAGE PLPGSQL;
